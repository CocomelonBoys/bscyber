# Only For UNIX

---
Set up Requirement
---
```
sudo apt-get install python3
sudo apt install git
sudo apt install python3-pip
git clone https://github.com/HugoXOX3/PythonMiner.git
cd PythonMiner
pip3 install lxml
python3 SoloMiner.py
```

---
Setup Setting
---

Input your bitcoin address and select pool and Enjoy mining


